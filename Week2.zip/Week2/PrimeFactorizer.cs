using System;
using System.Collections.Generic;
using System.Text;

namespace PrimeFactorLibrary
{
    public static class PrimeFactorizer
    {
        public static string PrimeFactors(int number)
        {
            if (number < 2 || number > 1000)
                throw new ArgumentOutOfRangeException(nameof(number), "Number must be between 2 and 1000.");

            List<int> factors = new List<int>();
            int divisor = 2;

            while (number > 1)
            {
                while (number % divisor == 0)
                {
                    factors.Add(divisor);
                    number /= divisor;
                }
                divisor++;
            }

            return string.Join(" x ", factors);
        }
    }
}
