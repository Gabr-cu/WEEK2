﻿namespace PrimeFactorLibrary;

public class Class1
{

}
